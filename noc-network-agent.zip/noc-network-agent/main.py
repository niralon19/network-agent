from __future__ import annotations

import argparse
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

from dotenv import load_dotenv

from noc_agent.core.memory import MemoryStore
from noc_agent.core.orchestrator import Orchestrator, OrchestratorConfig
from noc_agent.core.policy import PolicyEngine
from noc_agent.core.router import Router
from noc_agent.core.models import Alert
from noc_agent.observability.logging import configure_logging, log_event
from noc_agent.tools.runner import ToolRunner, ToolsConfig
from noc_agent.core.errors import PolicyDenied


def parse_alert(data: Dict[str, Any]) -> Alert:
    # Minimal validation, fail-fast.
    return Alert(
        id=str(data["id"]),
        ts=datetime.fromisoformat(data["ts"].replace("Z", "+00:00")) if isinstance(data["ts"], str) else data["ts"],
        service=str(data["service"]),
        domain=str(data.get("domain", "network")),
        severity=str(data.get("severity", "warn")),
        summary=str(data.get("summary", "")),
        labels=dict(data.get("labels", {})),
        annotations=dict(data.get("annotations", {})),
    )


def sample_alert(i: int) -> Dict[str, Any]:
    dst = f"10.0.0.{i%10}"
    iface = f"eth{i%6}"
    return {
        "id": f"sim-{i}",
        "ts": datetime.utcnow().isoformat() + "Z",
        "service": "edge-gw",
        "domain": "network",
        "severity": "critical" if i % 4 == 0 else "warn",
        "summary": "Network degradation detected",
        "labels": {"dst": dst, "iface": iface, "rule": "packet_loss", "port": "443"},
        "annotations": {},
    }


def build_orchestrator() -> Orchestrator:
    load_dotenv()

    configure_logging(os.getenv("LOG_LEVEL", "INFO"))
    dry_run = os.getenv("DRY_RUN", "true").lower() == "true"
    memory_db = os.getenv("MEMORY_DB", "./state/memory.sqlite")

    memory = MemoryStore(memory_db)
    policy = PolicyEngine(memory)
    router = Router()

    tools_cfg = ToolsConfig(
        grafana_url=os.getenv("GRAFANA_URL", ""),
        grafana_token=os.getenv("GRAFANA_TOKEN", ""),
    )
    tools = ToolRunner(tools_cfg)

    return Orchestrator(router=router, policy=policy, tools=tools, cfg=OrchestratorConfig(dry_run=dry_run))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--alert-file", type=str, default="", help="Path to alert JSON")
    ap.add_argument("--simulate", action="store_true", help="Generate synthetic alerts")
    ap.add_argument("--count", type=int, default=1, help="How many alerts to simulate")
    args = ap.parse_args()

    orch = build_orchestrator()

    if args.alert_file:
        data = json.loads(Path(args.alert_file).read_text(encoding="utf-8"))
        alerts = [parse_alert(data)]
    elif args.simulate:
        alerts = [parse_alert(sample_alert(i)) for i in range(args.count)]
    else:
        ap.print_help()
        return 2

    for a in alerts:
        try:
            res = orch.handle_alert(a)
            log_event("result", **res)
        except PolicyDenied as e:
            log_event("denied", reason=e.reason, alert_id=a.id, service=a.service)
        except Exception as e:
            log_event("error", error=str(e), alert_id=a.id, service=a.service)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
