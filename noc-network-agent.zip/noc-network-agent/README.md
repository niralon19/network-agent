# NOC Network Agent (Production‑grade, רזה)

סוכן תפעולי לטיפול בהתראות **Network** (הרמטיות / מטריקות Grafana / איבודים / לינקים / Ingress rate), עם **שלד נקי** להרחבה לתחומים נוספים.

הפרויקט בנוי בגישה:
- **Core Orchestrator אחד** שמנהל את הזרימה end‑to‑end
- **Experts לפי תחום** (כרגע: NetworkExpert)
- **Policies + Memory + Guardrails** כדי למנוע לופים ופעולות מסוכנות
- **Tools** מופרדים (Grafana / Network checks) עם Stub ברירת‑מחדל, כך שאפשר להחליף למימוש אמיתי בלי לשבור את הלוגיקה

---

## ארכיטקטורה (תקציר)

זרימה:
1. Ingest Alert (JSON / סימולציה)
2. Router מנתב ל‑Expert לפי `domain`
3. Expert מבצע Triage + Diagnostics
4. Policy Engine מחליט מה מותר לבצע (כולל Anti‑loop)
5. ToolRunner מבצע Actions (או DRY‑RUN)
6. Persist Memory + Report (logs)

קובץ ארכיטקטורה מלא: `docs/ARCHITECTURE.md`

---

## מבנה תיקיות

```
noc_network_agent/
├── main.py
├── noc_agent/
│   ├── core/
│   │   ├── orchestrator.py
│   │   ├── router.py
│   │   ├── policy.py
│   │   ├── memory.py
│   │   ├── models.py
│   │   └── errors.py
│   ├── experts/
│   │   ├── base.py
│   │   ├── network.py
│   │   └── generic.py
│   ├── tools/
│   │   ├── runner.py
│   │   ├── grafana.py
│   │   └── netchecks.py
│   └── observability/
│       └── logging.py
├── docs/
│   ├── ARCHITECTURE.md
│   └── PLAYBOOKS.md
├── examples/
│   ├── alert_network_loss.json
│   └── alert_network_link_flap.json
└── state/   (נוצר בהרצה)
```

---

## התקנה

דרישות:
- Python 3.10+ (מומלץ 3.11)

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

---

## הרצה (סימולציה)

### 1) להריץ על קובץ Alert לדוגמה
```bash
python main.py --alert-file examples/alert_network_loss.json
```

### 2) להריץ סימולטור שמייצר Alerts רנדומליים
```bash
python main.py --simulate --count 3
```

### 3) לכבות DRY‑RUN (רק אחרי שחיברת כלים אמיתיים)
```bash
DRY_RUN=false python main.py --alert-file examples/alert_network_loss.json
```

> כברירת‑מחדל, Tools הם Stub (לא באמת מבצעים פעולות מסוכנות). זה מכוון.

---

## איך להרחיב לתחום חדש (DB/App/Infra)

1. ליצור Expert חדש תחת `noc_agent/experts/<domain>.py`
2. לרשום אותו ב‑`router.py` תחת `DOMAIN_TO_EXPERT`
3. להוסיף Policies ייעודיים ב‑`policy.py` (אם צריך)
4. להוסיף Tools אם נדרש תחת `noc_agent/tools/`

---

## עקרונות Safety/Guardrails שכבר קיימים

- **Anti‑loop**: לא מאפשר לבצע אותה פעולה יותר מפעם ב‑30 דקות לאותו `service+signature`
- **Fail‑Closed**: אם Policy/Memory לא זמינים – לא מבצעים Actions מסוכנים
- **Approval**: Plan יכול לסמן `requires_approval` (כרגע מודגם ל‑Network)
- **DRY‑RUN**: מצב ברירת‑מחדל; תראה מה היה קורה בלי לבצע

---

## מה להחליף כדי לחבר לפרודקשן שלך

- `noc_agent/tools/grafana.py` – מימוש אמיתי לקריאה מ‑Grafana API
- `noc_agent/tools/netchecks.py` – מימוש ping/mtr/interface status מול ציוד/שרתים
- `noc_agent/tools/runner.py` – חיבור לפעולות (rate limit, open incident, וכו')
