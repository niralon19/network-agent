# Playbooks – Network

## 1) Packet Loss גבוה
**סימפטומים**
- `packet_loss_pct > 3%`
- עלייה ב־drops/errors

**אבחון**
- בדיקת reachability
- Grafana: drops/errors/retransmits
- mtr/traceroute אם יש הרשאה

**Plan מוצע**
- אם יש link flaps / CRC: לפתוח Incident לספק/פיזי
- אם inrate חריג + drops: לשקול rate limit (דורש approval)
- אם reachability כושלת לגמרי: escalation מיידי

---

## 2) Link Flaps
**סימפטומים**
- interface up/down מספר פעמים בפרק זמן קצר

**Plan מוצע**
- לעצור auto‑fix
- לפתוח Incident + לצרף סטטיסטיקות (flaps, CRC, speed/duplex)

---

## 3) Latency Spike
**Plan מוצע**
- להבדיל בין transient (spike קצר) ל־sustained
- אם sustained + retransmits: escalates / investigate upstream
