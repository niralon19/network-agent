# ארכיטקטורה – NOC Network Agent

## מטרות
- לקבל התראה → לבצע בדיקות רשת → להציע Plan בטוח → לבצע (או DRY‑RUN) → לדווח
- להיות **רזה**, דטרמיניסטי, ניתן לתחזוקה, וקל להרחבה לתחומים נוספים

## תרשים רכיבים

```mermaid
flowchart TB
  A[Alert Ingest<br/>main.py] --> B[Core Orchestrator]
  B --> C[Router]
  C -->|domain=network| D[NetworkExpert]
  C -->|fallback| E[GenericExpert]
  D --> F[Diagnostics]
  E --> F
  F --> G[Policy Engine]
  G -->|allowed| H[ToolRunner]
  G -->|deny| I[Report: denied]
  H --> J[Memory Store<br/>SQLite]
  I --> J
  J --> K[Observability<br/>structured logs]
```

## זרימת עבודה (State Machine)
1. **validate_alert** – ולידציה + נירמול מינימלי (אין “Normalize” כבד)
2. **route** – ניתוב deterministic לפי `alert.domain`
3. **triage** – בדיקות זולות ומהירות לקביעת scope
4. **diagnose** – בדיקות לפי סדר:
   - הרמטיות (reachability)
   - מטריקות Grafana
   - איבודים (packet loss)
   - לינקים (link state / flaps / errors)
   - inrate (ingress rate)
5. **propose_plan** – יצירת Plan בפורמט אחיד
6. **policy_gate** – חוקים:
   - External provider → ללא auto‑fix
   - פעולות מסוכנות → דורשות approval
   - Anti‑loop → חסימה אם בוצע לאחרונה
7. **execute** – ToolRunner מבצע פעולות (או מדמה)
8. **postcheck** – בדיקה קצרה לאחר פעולה (stub בדוגמה)
9. **persist + report** – כתיבה ל‑Memory ולוגים

## חוזים
- `Alert` – אובייקט התראה אחיד
- `DiagnosticReport` – תוצאות הבדיקות
- `Plan` – רשימת פעולות + דרישות approval + סיבות
- `Action` – פעולה אחת עם `idempotency_key` ו־`preconditions`

## עלות/סקייל
- כל Alert מטופל סינכרונית בתהליך אחד (Pod אחד)
- אפשר להוסיף תור (Rabbit/Kafka) בלי לשנות את לוגיקת ה‑Core
- Tools כוללים timeouts/retries (tenacity) כדי לא להיתקע
