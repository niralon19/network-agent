from __future__ import annotations

from ..core.models import Alert, DiagnosticReport, CheckResult, Plan, Action
from ..tools.runner import ToolRunner
from .base import BaseExpert


class GenericExpert(BaseExpert):
    def triage(self, alert: Alert) -> dict:
        return {"domain": alert.domain, "note": "generic fallback"}

    def diagnose(self, alert: Alert, tools: ToolRunner) -> DiagnosticReport:
        r = DiagnosticReport(confidence=0.2, blast_radius="unknown")
        r.add(CheckResult("noop", True, {"reason": "no expert available"}))
        return r

    def propose_plan(self, alert: Alert, report: DiagnosticReport) -> Plan:
        return Plan(
            actions=[Action(type="notify", params={"text": f"No expert for domain={alert.domain}."}, idempotency_key=f"notify:{alert.id}")],
            reason="No expert available",
            requires_approval=False,
            risk="low",
        )
