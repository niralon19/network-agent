from __future__ import annotations

import hashlib
from datetime import datetime
from typing import Any, Dict

from ..core.models import Alert, DiagnosticReport, CheckResult, Plan, Action
from ..tools.runner import ToolRunner
from .base import BaseExpert


class NetworkExpert(BaseExpert):
    """
    Network diagnostics in the exact order requested:
    1) hermeticity / reachability
    2) grafana metrics
    3) packet loss
    4) link checks
    5) inrate (ingress rate)
    """

    def triage(self, alert: Alert) -> dict:
        dst = alert.labels.get("dst") or alert.annotations.get("dst")
        iface = alert.labels.get("iface") or alert.annotations.get("iface")
        provider = alert.labels.get("provider")
        return {
            "dst": dst,
            "iface": iface,
            "is_external_provider": bool(provider),
            "needs_deep_dive": alert.severity in ("warn", "critical"),
        }

    def diagnose(self, alert: Alert, tools: ToolRunner) -> DiagnosticReport:
        dst = alert.labels.get("dst", "")
        iface = alert.labels.get("iface", "")
        report = DiagnosticReport(blast_radius=self._infer_blast_radius(alert))

        # 1) Reachability (הרמטיות)
        reach = tools.net.reachability(dst=dst, port=int(alert.labels.get("port", "443") or 443))
        report.add(CheckResult("reachability", ok=reach["ok"], details=reach))

        # 2) Grafana metrics
        metrics = tools.grafana.network_metrics(service=alert.service, iface=iface, window="10m")
        report.add(CheckResult("grafana_metrics", ok=metrics["ok"], details=metrics))

        # 3) Packet loss
        pl = tools.net.packet_loss(dst=dst, samples=20)
        report.add(CheckResult("packet_loss", ok=(pl["loss_pct"] < 3.0), details=pl))

        # 4) Link state
        link = tools.net.link_status(iface=iface)
        report.add(CheckResult("link_state", ok=link["ok"], details=link))

        # 5) Ingress rate
        inrate = tools.grafana.ingress_rate(service=alert.service, iface=iface, window="10m")
        report.add(CheckResult("ingress_rate", ok=inrate["ok"], details=inrate))

        report.confidence = self._score_confidence(report)
        return report

    def propose_plan(self, alert: Alert, report: DiagnosticReport) -> Plan:
        # Basic interpretation
        reach_ok = report.ok("reachability")
        loss = next((c.details.get("loss_pct") for c in report.checks if c.name == "packet_loss"), 0.0)
        link = next((c.details for c in report.checks if c.name == "link_state"), {})
        inrate = next((c.details for c in report.checks if c.name == "ingress_rate"), {})
        drops = next((c.details.get("drops_spike") for c in report.checks if c.name == "grafana_metrics"), False)

        actions = []
        risk = "low"
        requires_approval = False

        if reach_ok is False:
            actions.append(self._action("escalate", {"reason": "reachability_failed"}, alert))
            actions.append(self._action("open_incident", {"category": "network", "reason": "hard_outage"}, alert))
            risk = "high"
            requires_approval = True

        # Link flaps / CRC errors -> open incident
        if link.get("flaps_10m", 0) >= 3 or link.get("crc_errors", 0) > 0:
            actions.append(self._action("open_incident", {"category": "network", "reason": "link_instability", "link": link}, alert))
            risk = max(risk, "medium", key=["low","medium","high"].index)
            requires_approval = True

        # Inrate high + drops + loss -> rate limit suggestion (approval)
        if inrate.get("inrate_high") and (drops or loss >= 3.0):
            actions.append(self._action("rate_limit_ingress", {"iface": alert.labels.get("iface"), "reason": "high_inrate_with_loss_or_drops"}, alert, approval=True))
            risk = "high"
            requires_approval = True

        if not actions:
            actions.append(self._action("notify", {"text": "Network checks did not confirm an incident. Monitor and re-check."}, alert))

        reason = "Network diagnostics completed"
        return Plan(actions=actions, reason=reason, requires_approval=requires_approval, risk=risk)

    def _action(self, typ: str, params: Dict[str, Any], alert: Alert, approval: bool = False) -> Action:
        raw = f"{typ}|{alert.service}|{alert.signature}|{json_stable(params)}"
        idem = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]
        return Action(type=typ, params=params, idempotency_key=idem, requires_approval=approval)

    def _infer_blast_radius(self, alert: Alert) -> str:
        if alert.labels.get("iface"):
            return "single_iface"
        if alert.labels.get("zone"):
            return "zone"
        return "unknown"

    def _score_confidence(self, report: DiagnosticReport) -> float:
        # Simple deterministic scoring: more failed checks => higher confidence that something is wrong.
        if not report.checks:
            return 0.0
        fails = sum(1 for c in report.checks if not c.ok)
        base = fails / len(report.checks)
        # weight reachability and packet loss slightly more
        reach = report.ok("reachability")
        if reach is False:
            base += 0.2
        loss = next((c.details.get("loss_pct") for c in report.checks if c.name == "packet_loss"), 0.0)
        if loss >= 3.0:
            base += 0.2
        return max(0.0, min(1.0, base))


def json_stable(d: Dict[str, Any]) -> str:
    # stable str for idempotency key input
    items = sorted((k, str(v)) for k, v in d.items())
    return "|".join(f"{k}={v}" for k, v in items)
