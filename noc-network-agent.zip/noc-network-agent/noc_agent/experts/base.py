from __future__ import annotations

from abc import ABC, abstractmethod

from ..core.models import Alert, DiagnosticReport, Plan
from ..tools.runner import ToolRunner


class BaseExpert(ABC):
    @abstractmethod
    def triage(self, alert: Alert) -> dict:
        raise NotImplementedError

    @abstractmethod
    def diagnose(self, alert: Alert, tools: ToolRunner) -> DiagnosticReport:
        raise NotImplementedError

    @abstractmethod
    def propose_plan(self, alert: Alert, report: DiagnosticReport) -> Plan:
        raise NotImplementedError
