from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta, datetime
from typing import Tuple

from .errors import PolicyDenied
from .models import Alert, Plan, Action
from .memory import MemoryStore


@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    reason: str = ""
    requires_approval: bool = False


class PolicyEngine:
    """
    Deterministic, fail-closed policies.
    """

    def __init__(self, memory: MemoryStore, anti_loop_window: timedelta = timedelta(minutes=30)):
        self.memory = memory
        self.anti_loop_window = anti_loop_window

    def gate_plan(self, alert: Alert, plan: Plan) -> PolicyDecision:
        # External provider - no auto fix
        if alert.labels.get("provider"):
            # allow only notify/escalate/open_incident
            for a in plan.actions:
                if a.type not in ("notify", "open_incident", "escalate"):
                    return PolicyDecision(False, "external_provider_no_autofix")
            return PolicyDecision(True, requires_approval=True, reason="external_provider")

        # Anti-loop: block any "mutating" action if recently done for same signature.
        for a in plan.actions:
            if a.type in ("rate_limit_ingress", "block_ip", "restart_link", "change_route"):
                if not self.memory.is_action_allowed(a.type, alert.service, alert.signature, self.anti_loop_window):
                    return PolicyDecision(False, f"anti_loop_blocked:{a.type}")
        # Approval for medium/high risk
        if plan.risk in ("medium", "high") or plan.requires_approval:
            return PolicyDecision(True, requires_approval=True, reason="risky_plan")
        return PolicyDecision(True, requires_approval=False, reason="ok")

    def record_actions(self, alert: Alert, plan: Plan) -> None:
        now = datetime.utcnow()
        for a in plan.actions:
            if a.type in ("rate_limit_ingress", "block_ip", "restart_link", "change_route"):
                self.memory.upsert_action(a.type, alert.service, alert.signature, a.idempotency_key, now)
