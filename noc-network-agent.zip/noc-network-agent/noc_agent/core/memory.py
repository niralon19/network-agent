from __future__ import annotations

import os
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional


@dataclass
class RecentAction:
    action_type: str
    service: str
    signature: str
    idempotency_key: str
    ts: datetime


class MemoryStore:
    """
    Minimal durable memory for anti-loop + correlation.
    SQLite is enough for a single-pod design and is easy to operationalize.
    """

    def __init__(self, db_path: str):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._init()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.db_path)
        con.execute("PRAGMA journal_mode=WAL;")
        con.execute("PRAGMA synchronous=NORMAL;")
        return con

    def _init(self) -> None:
        with self._connect() as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS recent_actions (
                  action_type TEXT NOT NULL,
                  service TEXT NOT NULL,
                  signature TEXT NOT NULL,
                  idempotency_key TEXT NOT NULL,
                  ts TEXT NOT NULL,
                  PRIMARY KEY (action_type, service, signature)
                )
                """
            )

    def upsert_action(self, action_type: str, service: str, signature: str, idempotency_key: str, ts: datetime) -> None:
        with self._connect() as con:
            con.execute(
                """
                INSERT INTO recent_actions(action_type, service, signature, idempotency_key, ts)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(action_type, service, signature) DO UPDATE SET
                  idempotency_key=excluded.idempotency_key,
                  ts=excluded.ts
                """,
                (action_type, service, signature, idempotency_key, ts.isoformat()),
            )

    def get_recent_action(self, action_type: str, service: str, signature: str) -> Optional[RecentAction]:
        with self._connect() as con:
            row = con.execute(
                "SELECT action_type, service, signature, idempotency_key, ts FROM recent_actions WHERE action_type=? AND service=? AND signature=?",
                (action_type, service, signature),
            ).fetchone()
        if not row:
            return None
        return RecentAction(row[0], row[1], row[2], row[3], datetime.fromisoformat(row[4]))

    def is_action_allowed(self, action_type: str, service: str, signature: str, window: timedelta) -> bool:
        ra = self.get_recent_action(action_type, service, signature)
        if not ra:
            return True
        return (datetime.utcnow() - ra.ts) > window
