from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Literal


Severity = Literal["info", "warn", "critical"]


@dataclass(frozen=True)
class Alert:
    id: str
    ts: datetime
    service: str
    domain: str  # "network" | "db" | "app" | ...
    severity: Severity
    summary: str
    labels: Dict[str, str] = field(default_factory=dict)
    annotations: Dict[str, str] = field(default_factory=dict)

    @property
    def signature(self) -> str:
        """
        Stable signature used for dedup/anti-loop.
        Keep it conservative: include service + rule/summary + key labels.
        """
        rule = self.labels.get("rule") or self.annotations.get("rule") or self.summary
        key = f"{self.service}|{self.domain}|{rule}|{self.labels.get('iface','')}|{self.labels.get('dst','')}"
        return key


@dataclass
class CheckResult:
    name: str
    ok: bool
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DiagnosticReport:
    checks: List[CheckResult] = field(default_factory=list)
    confidence: float = 0.0  # 0..1
    blast_radius: str = "unknown"  # "single_iface"|"zone"|"global"|"unknown"
    notes: List[str] = field(default_factory=list)

    def add(self, result: CheckResult) -> None:
        self.checks.append(result)

    def ok(self, name: str) -> Optional[bool]:
        for c in self.checks:
            if c.name == name:
                return c.ok
        return None


@dataclass(frozen=True)
class Action:
    type: str  # "open_incident"|"rate_limit_ingress"|"escalate"|"notify"
    params: Dict[str, Any] = field(default_factory=dict)
    idempotency_key: str = ""
    requires_approval: bool = False


@dataclass
class Plan:
    actions: List[Action] = field(default_factory=list)
    reason: str = ""
    requires_approval: bool = False
    risk: str = "low"  # "low"|"medium"|"high"
