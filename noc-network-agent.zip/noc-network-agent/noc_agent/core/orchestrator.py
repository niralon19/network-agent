from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from ..observability.logging import log_event
from ..tools.runner import ToolRunner
from .errors import PolicyDenied
from .models import Alert, Plan
from .policy import PolicyEngine
from .router import Router


@dataclass
class OrchestratorConfig:
    dry_run: bool = True


class Orchestrator:
    def __init__(self, router: Router, policy: PolicyEngine, tools: ToolRunner, cfg: OrchestratorConfig):
        self.router = router
        self.policy = policy
        self.tools = tools
        self.cfg = cfg

    def handle_alert(self, alert: Alert) -> dict:
        correlation_id = str(uuid.uuid4())
        log_event("alert_received", correlation_id=correlation_id, alert_id=alert.id, service=alert.service, domain=alert.domain, severity=alert.severity)

        expert_cls = self.router.route(alert.domain)
        expert = expert_cls()

        triage = expert.triage(alert)
        log_event("triage", correlation_id=correlation_id, triage=triage)

        report = expert.diagnose(alert, self.tools)
        log_event("diagnostics", correlation_id=correlation_id, checks=[{"name": c.name, "ok": c.ok, "details": c.details} for c in report.checks], confidence=report.confidence, blast_radius=report.blast_radius)

        plan: Plan = expert.propose_plan(alert, report)
        log_event("plan_proposed", correlation_id=correlation_id, plan={"reason": plan.reason, "risk": plan.risk, "requires_approval": plan.requires_approval, "actions": [a.type for a in plan.actions]})

        decision = self.policy.gate_plan(alert, plan)
        log_event("policy_decision", correlation_id=correlation_id, allowed=decision.allowed, requires_approval=decision.requires_approval, reason=decision.reason)

        if not decision.allowed:
            raise PolicyDenied(decision.reason)

        executed = []
        if decision.requires_approval:
            # In this template we "soft stop" and only notify.
            executed.append(self.tools.notify(alert, plan, correlation_id=correlation_id, dry_run=self.cfg.dry_run, note="Approval required; execution paused."))
        else:
            for action in plan.actions:
                executed.append(self.tools.execute_action(alert, action, correlation_id=correlation_id, dry_run=self.cfg.dry_run))

        # Record only after execution attempt (or after approval gate if you prefer)
        self.policy.record_actions(alert, plan)

        log_event("alert_done", correlation_id=correlation_id, executed=executed)
        return {"correlation_id": correlation_id, "executed": executed, "plan": plan.reason, "risk": plan.risk}
