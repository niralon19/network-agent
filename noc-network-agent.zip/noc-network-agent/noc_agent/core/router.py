from __future__ import annotations

from typing import Dict, Type

from ..experts.base import BaseExpert
from ..experts.network import NetworkExpert
from ..experts.generic import GenericExpert


DOMAIN_TO_EXPERT: Dict[str, Type[BaseExpert]] = {
    "network": NetworkExpert,
    # הרחבה:
    # "db": DBExpert,
    # "app": AppExpert,
    # "infra": InfraExpert,
}


class Router:
    def route(self, domain: str) -> Type[BaseExpert]:
        return DOMAIN_TO_EXPERT.get(domain, GenericExpert)
