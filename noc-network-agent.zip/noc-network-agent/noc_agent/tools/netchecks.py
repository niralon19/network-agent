from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, Any

from tenacity import retry, stop_after_attempt, wait_exponential


@dataclass
class NetChecksConfig:
    # Add endpoints/credentials if needed.
    pass


class NetChecks:
    """
    Stubbed network checks.
    Replace with real implementations (ping/mtr, SNMP, ethtool, device APIs, etc).
    """

    def __init__(self, cfg: NetChecksConfig | None = None):
        self.cfg = cfg or NetChecksConfig()

    @retry(stop=stop_after_attempt(2), wait=wait_exponential(min=0.1, max=0.5))
    def reachability(self, dst: str, port: int = 443) -> Dict[str, Any]:
        if not dst:
            return {"ok": True, "note": "no dst provided"}
        # deterministic-ish: last char digit influences
        digit = int(dst[-1]) if dst and dst[-1].isdigit() else 1
        ok = (digit % 9 != 0)  # fail sometimes
        return {"ok": ok, "dst": dst, "tcp_port": port, "icmp": ok, "tcp": ok}

    @retry(stop=stop_after_attempt(2), wait=wait_exponential(min=0.1, max=0.5))
    def packet_loss(self, dst: str, samples: int = 20) -> Dict[str, Any]:
        if not dst:
            return {"loss_pct": 0.0, "samples": samples, "note": "no dst"}
        digit = int(dst[-1]) if dst and dst[-1].isdigit() else 1
        loss = 0.5 if digit % 4 else 3.5 if digit % 8 == 0 else 1.5
        return {"loss_pct": float(loss), "samples": samples, "dst": dst}

    @retry(stop=stop_after_attempt(2), wait=wait_exponential(min=0.1, max=0.5))
    def link_status(self, iface: str) -> Dict[str, Any]:
        if not iface:
            return {"ok": True, "note": "no iface"}
        # deterministic based on length
        flaps = 0 if len(iface) % 3 else 4
        crc = 0 if len(iface) % 5 else 12
        ok = (flaps < 3 and crc == 0)
        return {"ok": ok, "iface": iface, "flaps_10m": flaps, "crc_errors": crc, "link_up": True}
