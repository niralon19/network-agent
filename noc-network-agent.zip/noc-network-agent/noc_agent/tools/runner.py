from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict

from ..observability.logging import log_event
from ..core.models import Alert, Action, Plan
from .grafana import GrafanaClient, GrafanaClientConfig
from .netchecks import NetChecks, NetChecksConfig


@dataclass
class ToolsConfig:
    grafana_url: str = ""
    grafana_token: str = ""


class ToolRunner:
    """
    Centralized execution boundary.
    - All side effects pass through here.
    - Supports DRY-RUN.
    """

    def __init__(self, cfg: ToolsConfig):
        self.grafana = GrafanaClient(GrafanaClientConfig(url=cfg.grafana_url, token=cfg.grafana_token))
        self.net = NetChecks(NetChecksConfig())

    def execute_action(self, alert: Alert, action: Action, correlation_id: str, dry_run: bool) -> Dict[str, Any]:
        log_event("action_execute", correlation_id=correlation_id, action=action.type, dry_run=dry_run, params=action.params)

        if dry_run:
            return {"action": action.type, "status": "dry_run", "params": action.params}

        # Implement real actions here (ITSM, router config, rate-limit, etc).
        if action.type == "notify":
            return {"action": "notify", "status": "ok"}
        if action.type == "open_incident":
            return {"action": "open_incident", "status": "ok", "ticket": "INC-0001"}
        if action.type == "escalate":
            return {"action": "escalate", "status": "ok"}
        if action.type == "rate_limit_ingress":
            # Dangerous - should be behind approval in policy
            return {"action": "rate_limit_ingress", "status": "ok"}
        return {"action": action.type, "status": "unknown_action"}

    def notify(self, alert: Alert, plan: Plan, correlation_id: str, dry_run: bool, note: str) -> Dict[str, Any]:
        # A single place to integrate Slack/Jira/etc.
        log_event("notify", correlation_id=correlation_id, service=alert.service, domain=alert.domain, note=note, dry_run=dry_run, plan_reason=plan.reason)
        return {"action": "notify", "status": "dry_run" if dry_run else "ok", "note": note}
