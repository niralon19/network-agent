from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Dict, Any

from tenacity import retry, stop_after_attempt, wait_exponential


@dataclass
class GrafanaClientConfig:
    url: str = ""
    token: str = ""


class GrafanaClient:
    """
    Stub client by default.
    Replace methods with real Grafana API queries (Prometheus datasource / Loki etc).
    """

    def __init__(self, cfg: GrafanaClientConfig):
        self.cfg = cfg

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=0.2, max=1.0))
    def network_metrics(self, service: str, iface: str, window: str = "10m") -> Dict[str, Any]:
        # TODO: Implement real query.
        # Stub logic: random-ish spikes based on iface hash to keep deterministic per run.
        seed = (service + "|" + iface).encode("utf-8")
        h = int.from_bytes(seed[:2], "little", signed=False) if seed else 0
        drops_spike = (h % 5 == 0)
        return {
            "ok": True,
            "window": window,
            "latency_p95_ms": 25.0 + (h % 20),
            "drops_spike": drops_spike,
            "errors_spike": (h % 7 == 0),
        }

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=0.2, max=1.0))
    def ingress_rate(self, service: str, iface: str, window: str = "10m") -> Dict[str, Any]:
        seed = (iface + "|" + service).encode("utf-8")
        h = int.from_bytes(seed[-2:], "little", signed=False) if seed else 0
        pps = 10_000 + (h % 40_000)
        inrate_high = pps > 35_000
        return {"ok": True, "window": window, "ingress_pps": pps, "inrate_high": inrate_high}
