import json
import logging
from datetime import datetime
from typing import Any, Dict


def configure_logging(level: str = "INFO") -> None:
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO), format="%(message)s")


def log_event(event: str, **fields: Any) -> None:
    payload: Dict[str, Any] = {
        "ts": datetime.utcnow().isoformat() + "Z",
        "event": event,
        **fields,
    }
    logging.getLogger("noc-agent").info(json.dumps(payload, ensure_ascii=False))
